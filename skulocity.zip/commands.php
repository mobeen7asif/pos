<?php

// remove folder
//system('rm -rf vendor');

//exit('before');
//system('unzip vendor.zip');
echo 'before';

//$output = shell_exec('php artisan migrate');
//echo "<pre>$output</pre>";  

echo 'command run';
exit;
    
?>
