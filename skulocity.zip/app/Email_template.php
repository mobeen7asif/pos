<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use Auth;
use Mail;

class Email_template extends Model
{
    
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'email_templates';

    /**
    * The database primary key value.
    *
    * @var string
    */
    protected $primaryKey = 'id';
    
    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = ['updated_at'];
    

    public static function sendEmail($to,$email_data,$body)
    {

        $res['final_content'] = $body;
        try {
            Mail::send('emails.email_body',$res, function ($message) use ($email_data, $to) {
                $message->from('info@skulocity.com', $email_data->name);
                $message->to($to, $to)->subject($email_data->subject);
            });
        }catch (Exception $e) {
            echo $e->getMessage();
        }
    }
    
    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['name', 'subject', 'from', 'content','template_key','company_id'];
    
	
}
