<?php

namespace App\Http\Controllers\Company;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Categories;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use Response;
use Image;
use File;
use Session;
use Alert;
use Datatables;
use Hashids;
use App\User;
use App\Product;
use App\Product_images;
use App\Store;
use App\Store_products;
use App\Category_products;
use App\Product_variant;
use App\Product_tag;
use App\Product_stock;
use App\Variant;
use App\Order;
use App\Shipping_option;
use App\Tax_rates;
use App\Customer;

class OrderController extends Controller
{
    public $successStatus = 200;
    public $errorStatus = 401;
    public $notFoundStatus = 404;
    public $validationStatus = 422;
    
    /**
     * Display a listing of the resource.
     *
     * @return JS0N Response
     */
    public function index()
    {      
       //Order::whereIn('reference',[620180504183744,620180504185929,920180504123918,620180504183053,620180509174703,620180509175151])->delete();
        return view('company.orders.index');
    }        
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function getOrders(Request $request)
    {
        
        //$store_ids = Store::where('company_id',Auth::id())->pluck('id');
        
        $orders = Order::with(['store','customers'])->whereIn('store_id',getStoreIds());     
        
        if($request->order_type==1){
            $orders->where('order_id',0);
        }elseif($request->order_type==2){
            $orders->where('order_id','!=',0);            
        } 
        
        $orders = $orders->orderBy('updated_at','desc')->get(); 
        
        return Datatables::of($orders)
            ->addColumn('date', function ($order) {
                return date('d/m/Y', strtotime($order->created_at));                
            })
            ->addColumn('store_name', function ($order) {
                return $order->store->name;
            })
            ->addColumn('biller_name', function ($order) {
                $biller = json_decode($order->biller_detail);
                return $biller->name;
            })
            ->addColumn('customer', function ($order) {                
                return $order->customers->first_name.' '.$order->customers->last_name;
            })
            ->addColumn('order_status', function ($order) {
                if($order->order_status == 1){
                    return '<a href="javascript:void(0)" class="btn btn-xs btn-success" data-toggle="tooltip" title="Completed">Completed</a>';
                }else{
                    return '<a href="javascript:void(0)" class="btn btn-xs btn-danger" data-toggle="tooltip" title="Pending">Pending</a>';
                }               
            })
            ->addColumn('payment_status', function ($order) {
                if($order->payment_status == 2){
                    return '<a href="javascript:void(0)" class="btn btn-xs btn-success" data-toggle="tooltip" title="Paid">Paid</a>';
                }else if($order->payment_status == 1){
                    return '<a href="javascript:void(0)" class="btn btn-xs btn-info" data-toggle="tooltip" title="Partial">Partial</a>';
                }else{
                    return '<a href="javascript:void(0)" class="btn btn-xs btn-danger" data-toggle="tooltip" title="Pending">Pending</a>';
                }               
            })
            ->addColumn('order_type', function ($order) {
                if($order->order_id == 0){
                    return '<a href="javascript:void(0)" class="btn btn-xs btn-success" data-toggle="tooltip" title="Sales">Sales</a>';
                }else if($order->order_id != 0){
                    return '<a href="javascript:void(0)" class="btn btn-xs btn-danger" data-toggle="tooltip" title="Sales Return">Return</a>';
                }               
            })           
            ->addColumn('sub_total', function ($order) {
                return number_format($order->sub_total, 2);            
            })
            ->addColumn('order_total', function ($order) {
                return number_format($order->order_total, 2);            
            })
            ->addColumn('action', function ($order) {
                return '<a href="invoice/'. Hashids::encode($order->id).'" class="text-success btn-order" data-toggle="tooltip" title="View Order" id="'.$order->id.'"><i class="fa fa-eye"></i></a>';
            })
            ->rawColumns(['date', 'store_name', 'biller_name', 'order_status', 'payment_status', 'order_type', 'action'])
            ->editColumn('id', 'ID: {{$id}}')
            ->make(true);
            
    }
     
    //search orders
    public function searchOrders(Request $request)
    {      
        //  Order::destroy([563]);      
        if(\Request::wantsJson()) 
        {
            //Order::where('reference',220180503144816)->delete();
            
            $store_id = Auth::user()->store_id;
            
            $orders = Order::with(['store','customers.orders','shipping_option'])->where('store_id',$store_id);      
                           
            if(!empty($request->order_type)){
                if($request->order_type == 'sales'){
                   $orders->where('order_id',0); 
                }elseif($request->order_type == 'returns'){
                   $orders->where('order_id', '!=', 0);  
                }
                
            } 
            
            if(!empty($request->q)){
                
                if(is_numeric($request->q))
                    $orders->whereRaw('reference::TEXT LIKE '."'%$request->q%'");
                else
                    $orders->customer($request->q);
                
               // $test = $orders->whereRaw('reference::TEXT LIKE '."'$request->q%'");
               // if(!$test->first())
               
            }
            
            if(!empty($request->reference)){
                $orders->whereRaw('reference::TEXT LIKE '."'%$request->reference%'");
            }     
             
            if(!empty($request->customer)){
                $orders->where('customer',$request->customer);
            } 
            
            if(!empty($request->from_date)){
                $orders->where('created_at', '>=' , date('Y-m-d', strtotime($request->from_date)).' 00:00:00');
            }
            
            if(!empty($request->to_date)){
                $orders->where('created_at', '<=' , date('Y-m-d', strtotime($request->to_date)).' 23:59:59');
            }            
            
            $orders->orderBy('updated_at','desc');
            
           // dd($orders->get()->toArray());        
            
            if(!empty($request->limit)){
                if($request->limit=='all')
                    $orders = $orders->paginate($orders->count());
                else
                    $orders = $orders->paginate($request->limit);
            }else
                $orders = $orders->paginate(10);
            
            $orders->setCollection(
                $orders->getCollection()->map(function ($order) {  

                    if($order->biller_detail != "")
                        $order['biller_detail'] = json_decode($order->biller_detail);                                                    
                    
                    if($order->shipping_detail != "")
                        $order['shipping_detail'] = json_decode($order->shipping_detail);
                    else
                        $order['shipping_detail'] = NULL;        

                    if($order->order_items != ""){
                        $order_items = json_decode($order->order_items);       
                        
                        foreach($order_items as $order_item){ 

                            if(isset($order_item->tax_details))
                                $order_item->tax_details = json_decode($order_item->tax_details);
                            if(isset($order_item->item_combos))
                                $order_item->item_combos = json_decode($order_item->item_combos);
                            if(isset($order_item->item_modifiers))
                                $order_item->item_modifiers = json_decode($order_item->item_modifiers);
                        }
                        
                        $order['order_items'] = $order_items;  
                    }
                    
                    if($order->return_ids != "")
                        $order['return_orders'] = json_decode($order->return_ids);                                 
                    else
                        $order['return_orders'] = NULL;    

                    unset($order->return_ids);
                    
                    if($order->customers->orders->count()>0){
                        $order->customers->total_sales = number_format($order->customers->orders->sum('order_total'),2);
                        $order->customers->total_visits = $order->customers->orders->count();
                        $order->customers->last_visit = $order->customers->orders->last()->created_at->format('d/m/Y');
                    }else{
                        $order->customers->total_sales = 0;
                        $order->customers->total_visits = 0;
                        $order->customers->last_visit = '';
                    }
                     unset($order->customers->orders);       

                    return $order;

                })          
        );
            
        $response['orders'] = $orders;  

        $status = $this->successStatus;

        return response()->json(['result' => $response], $status);
        }
    }
    
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {                            
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return JSON Response
     */
    public function store(Request $request)
    {           
        $validator = Validator::make($request->all(), [
            'discount' => 'required', 
            'order_status' => 'required', 
            'payment_status' => 'required', 
            'sub_total' => 'required',
            'service_fee' => 'required',
            'order_total' => 'required',
            'order_items' => 'required',
            'customer' => 'required',
            'shipping_id' => 'required',
            'reference' => 'required',
            'payment_received' => 'required',  
            'payment_method' => 'required', 
        ]); 
        
        if ($validator->fails()) {
            $response['error'] = $validator->errors();
            return response()->json(['result'=>$response], $this->validationStatus);                 
        }
        
        $requestData = $request->all();

        $user = User::select(['id','name','email','phone','store_id'])->find(Auth::id());
        
        $order_data['reference'] = $request->reference;
        $order = Order::firstOrNew($order_data);
        
        $order->biller_id = $user->id;
        $order->biller_detail = $user->toJson();
        $order->store_id = $user->store_id;  
        $order->order_id = 0;                                             
        $order->discount = $request->discount;   
        $order->order_status = $request->order_status;
        $order->payment_status = $request->payment_status;
        $order->payment_method = $request->payment_method;
        $order->payment_detail = $request->payment_detail;
        $order->payment_received = $request->payment_received;
        $order->order_note = $request->order_note;
        $order->staff_note = $request->staff_note;
        $order->order_total = $request->order_total;
        $order->service_fee = $request->service_fee;
        $order->sub_total = $request->sub_total;
        $order->order_tax = isset($request->vat_total) ? $request->vat_total : 0;
        $order->customer = $request->customer;
        $order->shipping_id = $request->shipping_id;
        
        $shipping_option = Shipping_option::select(['id','name','cost','company_id'])->find($request->shipping_id);        
        if($shipping_option)
            $order->shipping_detail = $shipping_option->toJson();   
        
        // save order items
        if(!empty($request->order_items))
        {        
            $items_data = [];
            $basket_size = 0;
            $cost_of_goods  = 0;
            
            $order_items = json_decode($request->order_items);
            foreach($order_items as $key => $item){
                if(isset($item->item_id)){
                    $product_id = $item->item_id;
                    
                    $product = Product::with(['product','product_combos.product'])->find($product_id);
                    if($product){
                        $items_data[$key]['item_id'] = $product->id;
                        $items_data[$key]['item_image'] = getProductDefaultImage($product->id);
                        $items_data[$key]['item_name'] = $product->name;
                        if($product->product_id == 0){
                            $items_data[$key]['unit_cost'] = $product->cost;
                            $items_data[$key]['unit_price'] = $product->price;
                        }else{
                            if($product->is_main_price==0){
                                $items_data[$key]['unit_cost'] = $product->cost;
                                $items_data[$key]['unit_price'] = $product->price;
                            }elseif($product->is_main_price==1){
                                $items_data[$key]['unit_cost'] = $product->product->cost;
                                $items_data[$key]['unit_price'] = $product->product->price;                                
                            }                            
                        }
                        
                        $items_data[$key]['item_discount'] = $item->item_discount;
                        $items_data[$key]['quantity'] = $item->quantity;                        
                        $items_data[$key]['item_tagline'] = $item->item_tagline;                                                                        
                        
                        if($product->product_id == 0){
                            $tax_rate_id = $product->tax_rate_id;
                        }else{
                            if($product->is_main_tax==0){
                                $tax_rate_id = $product->tax_rate_id;                                
                            }elseif($product->is_main_tax==1){
                                $tax_rate_id = $product->product->tax_rate_id;
                            }  
                        }
                        
                        $tax = Tax_rates::select(['id','code','name','rate'])->find($tax_rate_id);
                        if($tax){
                            $items_data[$key]['tax_details'] = $tax->toJson();
                        }
                        
                        if($product->type==2){
                            $combo_collection = $product->product_combos->map(function ($item) {
                                return ['id' => $item->product->id, 'name' => $item->product->name, 'code' => $item->product->code, 'sku' => $item->product->sku];
                              });
                            
                            $items_data[$key]['item_combos'] = $combo_collection->toJson();
                        }
                        
                        if($product->is_modifier==1){
                            if(!empty($item->item_modifiers)){
                               $item_modifiers = explode(',', $item->item_modifiers); 
                               $modifier_data_collection = collect([]);
                               foreach($item_modifiers as $modifier_id){
                                   $modifier = Product::find($modifier_id);
                                    if($modifier){
                                        $modifier_data['id'] = $modifier->id;
                                        $modifier_data['name'] = $modifier->name;
                                        $modifier_data['cost'] = $modifier->cost;
                                        $modifier_data['price'] = $modifier->price;
                                        
                                        $cost_of_goods = $cost_of_goods + $modifier->cost; 
                                        
                                        $modifier_data_collection->push($modifier_data);
                                    }
                                   
                               }
                               
                               $items_data[$key]['item_modifiers'] = json_encode($modifier_data_collection);
                            }                                                        
                        }                                                                       
                        
                        $basket_size = $basket_size + $item->quantity;
                        $cost_of_goods = $cost_of_goods + ($product->cost*$item->quantity);
                        
                        // sync products
                        updateSyncData('product',$product->id);
                    }
                }                
                
            }
            
            $order->basket_size = $basket_size;
            $order->cost_of_goods = $cost_of_goods;
            $order->order_items = json_encode($items_data);
        }
                        
        $order->save();
             
        if($order){                                                               
            
            // sync order
            updateSyncData('order',$order->id);  
            //sendOrderEmail($order->id);
            updateOrderProductsStock($order->id);
            
            $response['reference'] = $order->reference;            
            $status = $this->successStatus;
            $response['success'] =  'You have successfully create order.';
        }else{
            $status = $this->errorStatus; 
            $response['record_id'] = 0;
            $response['error'] =  'Order not successfully created.';
        }                           
        
        return response()->json(['result'=>$response], $status);         
    }
    
     /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return JSON Response
     */
    public function salesReturn(Request $request)
    {   
        
        $validator = Validator::make($request->all(), [
            'order_id' => 'required', 
            'sub_total' => 'required',
            'order_total' => 'required',
            'order_items' => 'required',
            'customer' => 'required',
            'reference' => 'required',
        ]); 
        
        if ($validator->fails()) {
            $response['error'] = $validator->errors();
            return response()->json(['result'=>$response], $this->validationStatus);                 
        }
        
        $requestData = $request->all();
        $user = User::select(['id','name','email','phone','store_id'])->find(Auth::id());
        
        $order_data['reference'] = $request->reference;
        $order = Order::firstOrNew($order_data);
        
        $order->biller_id = $user->id;
        $order->biller_detail = $user->toJson();
        $order->store_id = $user->store_id;  
        $order->order_id = $request->order_id;;                                             
        $order->discount = 0;   
        $order->order_status = 1;
        $order->payment_status = 2;
        $order->payment_method = 1;
        $order->payment_detail = 'Sale Return';
        $order->payment_received = 0;
        $order->order_note = $request->order_note;
        $order->staff_note = $request->staff_note;
        $order->order_total = $request->order_total;
        $order->service_fee = 0;
        $order->sub_total = $request->sub_total;
        $order->order_tax = isset($request->vat_total) ? $request->vat_total : 0;
        $order->customer = $request->customer;
        $order->shipping_id = 0;
        $order->shipping_detail = '';        
        
        $order->save();
                
        $order = Order::find($order->id);
                
        if(!empty($request->order_items)){        
            $items_data = [];
            $basket_size = 0;
            $cost_of_goods  = 0;

            $order_items = json_decode($request->order_items);
            foreach($order_items as $key => $item){
                if(isset($item->item_id)){
                    $product_id = $item->item_id;

                    $items_data[$key]['item_id'] = $product_id;
                    if(!empty($item->item_image))
                        $items_data[$key]['item_image'] = $item->item_image;

                    $items_data[$key]['item_name'] = $item->item_name;
                    $items_data[$key]['unit_cost'] = $item->unit_cost;
                    $items_data[$key]['unit_price'] = $item->unit_price;
                    $items_data[$key]['total_price'] = $item->total_price;
                    $items_data[$key]['item_discount'] = $item->item_discount;
                    $items_data[$key]['quantity'] = $item->quantity;        
                    $items_data[$key]['tax_details'] = json_encode($item->tax_details);

                    if(!empty($item->item_modifiers))
                        $items_data[$key]['item_modifiers'] = json_encode($item->item_modifiers);

                    $basket_size = $basket_size + $item->quantity;
                    $cost_of_goods = $cost_of_goods + ($item->unit_cost*$item->quantity);

                    if(isset($item->item_modifiers)){
                        $item_modifiers = $item->item_modifiers;
                        foreach($item_modifiers as $item_modifier){
                            $cost_of_goods = $cost_of_goods+ $item_modifier->cost;                                
                        }
                    }

                    $product = Product::find($product_id);
                    if($product){
                        if(isset($item->inventory) && $item->inventory==1){
                            updateProductStockByData($product->id, $order->store_id, $item->quantity, 1, 4, $order->id, Auth::id(), $order->order_note);            
                        }
                        // sync products
                        updateSyncData('product',$product->id);
                    }
                }                

            }

            $order->basket_size = $basket_size;
            $order->cost_of_goods = $cost_of_goods;
            $order->order_items = json_encode($items_data);
        }
        
        $order->save(); 
             
        if($order){
            
            if($order->order_id>0){
                $this->saveReturnOrders($order->order_id,$order->id);                               
            }
            
            // sync order
            updateSyncData('order',$order->order_id);
            updateSyncData('order',$order->id);
            
            $response['order_id'] = $order->id;
            $response['reference'] = $order->reference;
            $status = $this->successStatus;
            $response['success'] =  'You have successfully create order.';
        }else{
            $status = $this->errorStatus; 
            $response['record_id'] = 0;
            $response['reference'] = 0;
            $response['error'] =  'Order not successfully created.';
        }                           
        
        return response()->json(['result'=>$response], $status);         
    }    
    
        /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return JSON Response
     */
    public function storeBulkOrders(Request $request)
    {        

       if(isset($request->orders)){
          $orders = json_decode($request->orders);
    
          foreach($orders as $order_request)
            {
                //$requestData = $order_request;
                $biller_id = $order_request->biller_id;
                
                $user = User::select(['id','name','email','phone','store_id'])->find($biller_id);                
                
                $order_data['reference'] = $order_request->reference;
                $order = Order::firstOrNew($order_data);

                $order->biller_id = $biller_id;
                $order->biller_detail = $user->toJson();
                $order->store_id = $user->store_id;                                                        
                $order->discount = $order_request->discount;   
                $order->order_status = $order_request->order_status;
                $order->payment_status = $order_request->payment_status;
                $order->payment_method = $order_request->payment_method;
                $order->payment_detail = $order_request->payment_detail;
                $order->payment_received = $order_request->payment_received;
                $order->order_note = $order_request->order_note;
                $order->staff_note = $order_request->staff_note;
                $order->order_total = $order_request->order_total;
                $order->service_fee = $order_request->service_fee;
                $order->sub_total = $order_request->sub_total;
                $order->order_tax = isset($order_request->vat_total) ? $order_request->vat_total : 0;
                $order->customer = $order_request->customer;
                $order->shipping_id = $order_request->shipping_id;

                $shipping_option = Shipping_option::select(['id','name','cost','company_id'])->find($order_request->shipping_id);        
                if($shipping_option)
                    $order->shipping_detail = $shipping_option->toJson();                
                
                $order->save();
                
                $order = Order::find($order->id);
                if(!empty($order_request->order_items))
                {        
                    $items_data = [];
                    $basket_size = 0;
                    $cost_of_goods  = 0;

                    $order_items = json_decode($order_request->order_items);                    

                    // sales return
                    if(isset($order_request->order_id) && $order_request->order_id>0)
                    {
                        foreach($order_items as $key => $item){
                            if(isset($item->item_id)){
                                $product_id = $item->item_id;

                                $items_data[$key]['item_id'] = $product_id;
                                $items_data[$key]['item_image'] = $item->item_image;
                                $items_data[$key]['item_name'] = $item->item_name;
                                $items_data[$key]['unit_cost'] = $item->unit_cost;
                                $items_data[$key]['unit_price'] = $item->unit_price;
                                $items_data[$key]['total_price'] = $item->total_price;
                                $items_data[$key]['item_discount'] = $item->item_discount;
                                $items_data[$key]['quantity'] = $item->quantity;        
                                $items_data[$key]['tax_details'] = json_encode($item->tax_details);                                    

                                $basket_size = $basket_size + $item->quantity;
                                $cost_of_goods = $cost_of_goods + ($item->unit_cost*$item->quantity);

                                if(isset($item->item_modifiers)){                                        
                                    $items_data[$key]['item_modifiers'] = json_encode($item->item_modifiers);
                                    $item_modifiers = $item->item_modifiers;
                                    foreach($item_modifiers as $item_modifier){
                                        $cost_of_goods = $cost_of_goods+ $item_modifier->cost;                                
                                    }
                                }

                                $product = Product::find($product_id);
                                if($product){
                                    if(isset($item->inventory) && $item->inventory==1){
                                        updateProductStockByData($product->id, $order->store_id, $item->quantity, 1, 4, $order->id, $biller_id, $order->order_note);            
                                    }
                                    // sync products
                                    updateSyncData('product',$product->id);
                                }
                            }                

                        }
                       $order->order_id = $order_request->order_id;  
                                              
                       $this->saveReturnOrders($order_request->order_id,$order->id);                               
            
                    }else
                    { // sales

                        foreach($order_items as $key => $item){
                            if(isset($item->item_id)){
                                $product_id = $item->item_id;

                                $product = Product::with(['product','product_combos.product'])->find($product_id);
                                if($product){
                                    $items_data[$key]['item_id'] = $product->id;
                                    $items_data[$key]['item_image'] = getProductDefaultImage($product->id);
                                    $items_data[$key]['item_name'] = $product->name;
                                    $items_data[$key]['unit_cost'] = $product->cost;
                                    $items_data[$key]['unit_price'] = $product->price;
                                    $items_data[$key]['item_discount'] = $item->item_discount;
                                    $items_data[$key]['quantity'] = $item->quantity;                        
                                    $items_data[$key]['item_tagline'] = $item->item_tagline;                                                                        

                                    if($product->product_id == 0){
                                        $tax_rate_id = $product->tax_rate_id;
                                    }else{
                                        if($product->is_main_tax==0){
                                            $tax_rate_id = $product->tax_rate_id;                                
                                        }elseif($product->is_main_tax==1){
                                            $tax_rate_id = $product->product->tax_rate_id;
                                        }  
                                    }

                                    $tax = Tax_rates::select(['id','code','name','rate'])->find($tax_rate_id);
                                    if($tax){
                                        $items_data[$key]['tax_details'] = $tax->toJson();
                                    }

                                    if($product->type==2){
                                        $combo_collection = $product->product_combos->map(function ($item) {

                                          return ['id' => $item->product->id, 'name' => $item->product->name, 'code' => $item->product->code, 'sku' => $item->product->sku];
                                        });

                                        $items_data[$key]['item_combos'] = $combo_collection->toJson();
                                    }

                                    if($product->is_modifier==1){
                                        if(!empty($item->item_modifiers)){
                                           $item_modifiers = explode(',', $item->item_modifiers); 
                                           $modifier_data_collection = collect([]);
                                           foreach($item_modifiers as $modifier_id){
                                               $modifier = Product::find($modifier_id);
                                                if($modifier){
                                                    $modifier_data['id'] = $modifier->id;
                                                    $modifier_data['name'] = $modifier->name;
                                                    $modifier_data['cost'] = $modifier->cost;
                                                    $modifier_data['price'] = $modifier->price;

                                                    $cost_of_goods = $cost_of_goods + $modifier->cost; 

                                                    $modifier_data_collection->push($modifier_data);
                                                }
                                           }

                                           $items_data[$key]['item_modifiers'] = json_encode($modifier_data_collection);
                                        }                                                        
                                    }                                                                       

                                    $basket_size = $basket_size + $item->quantity;
                                    $cost_of_goods = $cost_of_goods + ($product->cost*$item->quantity);
                                    
                                    // sync products
                                    updateSyncData('product',$product->id);
                                }
                            }                

                        }

                    }

                    $order->basket_size = $basket_size;
                    $order->cost_of_goods = $cost_of_goods;
                    $order->order_items = json_encode($items_data);
                }
                
                $order->save();
                if($order){  
                    
                    // sync order
                    if($order->order_id>0)
                        updateSyncData('order',$order->order_id);
                    
                    updateSyncData('order',$order->id);
                    //sendOrderEmail($order->id);
                    updateOrderProductsStock($order->id,$biller_id);                    
                }
          }
          
            $status = $this->successStatus;
            $response['success'] =  'You have successfully create orders.';
            
            return response()->json(['result'=>$response], $status); 
       }
                        
    }
    
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($category_id)
    {        
        $subcategory_id = '';
        return view('admin.items.index', compact('category_id','subcategory_id'));
    }
            
    
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return JS0N Response
     */
     public function edit($id)
    {                
        $order = Order::with(['store','customers'])->find($id);
        
        $order->date = date('d/m/Y h:j a', strtotime($order->created_at));
        $order->sub_total = number_format($order->sub_total,2);
        $order->order_total = number_format($order->order_total,2);
        
        if(!empty($order->biller_detail))
            $order->biller_detail = json_decode($order->biller_detail);
        
        if(!empty($order->order_items))
            $order->order_items = json_decode($order->order_items);
        if(!empty($order->order_items))
            $order->order_items = json_decode($order->order_items);
        
        if($order->shipping_id > 0)
            $order->shipping_detail = json_decode($order->shipping_detail);
        
        
        
        if($order){                
            $response['order'] = $order;
            $status = $this->successStatus;
        }else{
            $status = $this->notFoundStatus; 
            $response['record_id'] = $id;
            $response['error'] =  'Order not exist against this id.';
        }                           
        
        return response()->json(['result'=>$response], $status);
    }

    /**
     * Update the specified resource in storage.     
     *
     * @return JS0N Response
     */
    public function update(Request $request)
    {    

        $validator = Validator::make($request->all(), [
           // 'order_id' => 'required',  
            'payment_received' => 'required',  
            'payment_method' => 'required', 
        ]); 
        
        if ($validator->fails()) {
            $response['error'] = $validator->errors();
            return response()->json(['result'=>$response], $this->validationStatus);                 
        }
        
        $order = Order::find($request->order_id);
        
        $requestData = $request->all();                                                    

         if($order){
            $requestData['order_id'] = 0;
            $requestData['payment_status'] = 2;
            $requestData['order_status'] = 1;
            $order->update($requestData);    
            
            //sendOrderEmail($order->id);
            updateOrderProductsStock($order->id);
            
            $response['reference'] = $order->reference;
            $status = $this->successStatus;
            $response['success'] =  'Order successfully updated.';
        }else{
            $status = $this->notFoundStatus; 
            $response['record_id'] = $request->order_id;
            $response['error'] =  'Order not exist against this id.';
        }                           
        
        return response()->json(['result'=>$response], $status);   
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return JS0N Response
     */
    public function destroy($id)
    {
        if(\Request::ajax())
        {
            $id = Hashids::decode($id)[0];
        }        
        
        $product = Product::find($id);
        
        if($product){
            $product->delete();
            $response['success'] = 'Product deleted!';
            $status = $this->successStatus;  
        }else{
            $response['error'] = 'Product not exist against this id!';
            $status = $this->errorStatus;  
        }
        
        return response()->json(['result'=>$response], $status);
    }
    
    
    /**
    * Method : DELETE
    *
    * @return delete images
    */
    public function removeVariant($id) 
    {
    	$variant = Product_variant::findOrFail($id);
        if ($variant) {
            $variant->delete();
        }
                
        return response()->json(['success' => 1]);    
    }
    
    
    
    public function orderInvoice($id) {
        $id = Hashids::decode($id)[0];
        $order = Order::with(['store.currency','customers'])->where('id',$id)->first();      
        $data['order'] =  $order->toArray();
        return view('company.orders.invoice', $data);
            
    }
     
     /**
     * getOrdersMap function
     *
     * @param  int  $orders
     * 
     * @return \Illuminate\Http\Response
     */     
    public function getOrdersMap($orders)
    {
           
         // return $orders->all();
    } 
     
    /**
     * sendOrderEmail function
     *
     * @param  int  $order_id
     * 
     * @return \Illuminate\Http\Response
     */     
    public function sendOrderEmail($order_id)
    {
        sendOrderEmail($order_id);
        
        $status = $this->successStatus;
        $response['success'] =  'Email successfully sent.';                          
        
        return response()->json(['result'=>$response], $status);             
         
    } 
    
    /**
     * sendOrderEmailApi function
     *
     * @param  int  $request
     * 
     * @return \Illuminate\Http\Response
     */     
    public function sendOrderEmailApi(Request $request)
    {
 
        $order = Order::with(['store'])->where('reference',$request->reference)->first();  

        if (!$order) {
            $response['error'] = 'Order not exists against this id.';
            return response()->json(['result'=>$response], $this->notFoundStatus);                 
        }                
        
        if(isset($request->email)){
            $email = $request->email;
            $customer = Customer::where('email',$email)->first();
            if(!$customer){
                $customerData['id'] = Auth::id().date('Ymdhis');
                $customerData['first_name'] = '';
                $customerData['last_name'] = '';
                $customerData['email'] = $email;
                $customerData['company_id'] = $order->store->company_id;
                $customerData['store_id'] = $order->store_id;
                $customerData['currency_id'] = companySettingValueApi('currency_id');
                $customerData['profile_image'] = 'default.png';
                    
                $customer = Customer::create($customerData); 
                updateSyncData('customer',$customer->id);
                
                $order_data['customer'] = $customer->id;
                $order->update($order_data);
                
                updateSyncData('order',$order->id); 
            }                    
        }
        
        sendOrderEmail($order->id);
        
        
        $status = $this->successStatus;
        $response['success'] =  'Email successfully sent.';                          
        
        return response()->json(['result'=>$response], $status);             
         
    }
    
    function saveReturnOrders($parent_order_id,$order_id)
    {
        $main_order = Order::find($parent_order_id);  
        $return_order = Order::find($order_id);  
        $return_ids = $main_order->return_ids;
        if($return_ids!=""){
            $return_ids = json_decode($return_ids,true);   
            if(!find_key_value($return_ids, 'order_id', $order_id)){
                $count = COUNT($return_ids);
                $return_ids[$count]['order_id'] = $order_id;  
                $return_ids[$count]['reference'] = $return_order->reference;  
                $main_order->return_ids = json_encode($return_ids);
                $main_order->save();
            }
        }else{
            $return_data = [];
            $return_data[0]['order_id'] = $order_id;            
            $return_data[0]['reference'] = $return_order->reference;           
            $main_order->return_ids = json_encode($return_data);
            $main_order->save();
        }
    }
    
}
