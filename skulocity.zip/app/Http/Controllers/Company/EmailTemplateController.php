<?php

namespace App\Http\Controllers\Company;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

use App\Email_template;
use Illuminate\Http\Request;
use Session;
use Alert;
use Image;
use File;
use Hashids;
use Datatables;

class EmailTemplateController extends Controller
{
    public $successStatus = 200;
    public $errorStatus = 401;
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {          
        
        $email_template = Email_template::where('template_key','sale')->where('company_id',Auth::id())->first();
        if(!$email_template){
          $email_template = Email_template::where('template_key','sale')->where('company_id',0)->first();
        }
        return view('company.email-templates.form', compact('email_template'));
    }    

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update(Request $request)
    {        
        
        $this->validate($request, [
            'name' => 'required',   
            'subject' => 'required',            
            'from' => 'required',                                              
            'content' => 'required',                                              
        ]);                                   
        
        $requestData = $request->all();
        
        $templateData['company_id'] = Auth::id();
        $templateData['template_key'] = 'sale';
                
        $email_template = Email_template::where($templateData)->first();
        if($email_template){
            $email_template->name = $request->name;
            $email_template->subject = $request->subject;
            $email_template->from = $request->from;
            $email_template->content = $request->content;
            $email_template->save();
        }else{
           $requestData['company_id'] = Auth::id();
           $requestData['template_key'] = 'sale';
           
           Email_template::create($requestData);
        }
        
                                                
        
        Session::flash('success', 'Template updated!');  
        
        return redirect('company/email-template');
    }



}
