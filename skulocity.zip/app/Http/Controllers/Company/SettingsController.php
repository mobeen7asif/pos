<?php

namespace App\Http\Controllers\Company;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Session, Alert, DB;
use App\Admin;
use App\Company_setting;

class SettingsController extends Controller
{
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $setting = Company_setting::where('company_id',Auth::id())->first();
        
        return view('company.settings.settings', compact('setting'));
    }    

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update(Request $request)
    {
        
        $id = Auth::id();
        
        $this->validate($request, [             
            'currency_id' => 'required',
            'email' => 'required|email',
            'store_id' => 'required',
            'tax_id' => 'required',                                        
            'shipping_id' => 'required',                                        
        ]);
        
        $requestData = $request->all();                   
        
        $company = Company_setting::where('company_id',$id)->first();
        if($company){
            $company->update($requestData);  
        }else{
            $requestData['company_id'] = $id;
            Company_setting::create($requestData);
        }
              
        Session::flash('success', 'Settings updated!');

        return redirect('company/settings');
    }
    

}
