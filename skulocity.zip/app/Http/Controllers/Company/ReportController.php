<?php

namespace App\Http\Controllers\Company;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Categories;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use Response;
use Image;
use File;
use Session;
use Alert;
use Datatables;
use Hashids;
use App\User;
use App\Product;
use App\Store;
use App\Store_products;
use App\Stock;
use App\Order;
use App\Customer;
use DB;

class ReportController extends Controller
{
    public $successStatus = 200;
    public $errorStatus = 401;
    public $notFoundStatus = 404;
    
    /**
     * Display a listing of the resource.
     *
     * @return JS0N Response
     */
    public function index()
    {              
        return view('company.reports.index');
    }        
    
    /**
     * Display a listing of the resource.
     *
     * @return JSON
     */
    public function getRetailsDashboard(Request $request)
    {

        $orders = Order::whereIn('store_id',getStoreIds());
        
        if(!empty($request->store_id)){
            $store_id = Hashids::decode($request->store_id)[0];  
            $orders->where('store_id', $store_id);
        }
        
        if(!empty($request->from_date)){
            $orders->where('created_at', '>=' , date('Y-m-d', strtotime($request->from_date)).' 00:00:00');
        }

        if(!empty($request->to_date)){
            $orders->where('created_at', '<=' , date('Y-m-d', strtotime($request->to_date)).' 23:59:59');
        }
        
        $orders->get();        
                              
        $total_orders = $orders->get();
        //dd($orders->get()->toArray());
        
        $order_total = $orders->sum('order_total');
        $cost_of_goods = $orders->sum('cost_of_goods');
        
        $report['total_income'] = number_format($order_total,2);
        $report['total_sales'] = $orders->count();
        if($order_total>0)
            $report['total_profit'] = number_format($order_total-$cost_of_goods,2); 
        else
            $report['total_profit'] = number_format($order_total+$cost_of_goods,2);     
            
        $report['total_discount'] = number_format($orders->sum('discount'),2); 
        $report['discount_percentage'] = 0;        
        
        if($orders->sum('discount')>0 )
            $report['discount_percentage'] = number_format($orders->sum('sub_total')/$orders->sum('discount'),2); 
        
        $report['basket_value'] = number_format($orders->avg('order_total'),2);
        $report['basket_size'] = number_format($orders->avg('basket_size'),2);           
        $report['cash_sales'] = number_format($total_orders->where('payment_method',1)->sum('order_total'),2);
        $report['card_sales'] = number_format($total_orders->where('payment_method',2)->sum('order_total'),2);
        $report['total_customers'] = $total_orders->groupBy('customer')->count();                   
                     
        $status = $this->successStatus;
            
        return response()->json(['result' => $report], $status);
            
    }
       
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function getStoreStocksChart($id = '')
    {
        
        if(empty($id)){
          $product_ids = Store_products::pluck('product_id');  
        }else{
            $store_id = Hashids::decode($id)[0];  
            $product_ids = Store_products::where('store_id',$store_id)->pluck('product_id');  
        }
        
        
        $products = Product::with(['store_products'])->whereIn('id',$product_ids)->get();
          
        $total_products = $products->count();
        $total_product_quantity = Store_products::whereIn('product_id',$product_ids)->sum('quantity');
        
        $total_product_cost=0;
        $total_product_price=0;
        
        foreach($products as $product){
            $total_product_cost = $total_product_cost + ($product->cost * $product->store_products->sum('quantity'));
            $total_product_price = $total_product_price + ($product->price * $product->store_products->sum('quantity'));
        }
        
        $profit_estimate = $total_product_price - $total_product_cost;
        
        $report['total_products'] = number_format($total_products,2);
        $report['total_product_quantity'] = number_format($total_product_quantity,2);
        $report['total_product_cost'] = $total_product_cost;
        $report['total_product_price'] = $total_product_price;
        $report['profit_estimate'] = $profit_estimate;        
        
        return view('company.reports.stores_stock', compact('report'));
            
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return JS0N Response
     */
    public function salesReport()
    {                     
        
        $orders = Order::select(
                            DB::raw('DATE(created_at) as date'),
                            DB::raw('SUM(sub_total) as revenue'),
                            DB::raw('SUM(cost_of_goods) as cost_of_goods'),
                            DB::raw('SUM(order_tax) as order_tax')
                )->whereIn('store_id',getStoreIds());                                           
           
        $orders->where('store_id',2);
        
        $orders = $orders->groupBy('date')->orderBy('date', 'desc')->get();
                
        //dd($orders->toArray());
        
        return view('company.reports.sales');
    } 
    
    /**
     * Display a listing of the resource.
     *
     * @return JSON
     */
    public function getSalesReport(Request $request)
    {

        $orders = Order::select(
                            DB::raw('DATE(created_at) as date'),
                            DB::raw('SUM(order_total) as revenue'),
                            DB::raw('SUM(cost_of_goods) as cost_of_goods'),
                            DB::raw('SUM(order_tax) as order_tax')
                )->whereIn('store_id',getStoreIds());     
        
        if(!empty($request->store_id)){
            $store_id = Hashids::decode($request->store_id)[0];  
            $orders->where('store_id',$store_id);
        }
        
        if(!empty($request->from_date)){
            $orders->where('created_at', '>=' , date('Y-m-d', strtotime($request->from_date)).' 00:00:00');
        }

        if(!empty($request->to_date)){
            $orders->where('created_at', '<=' , date('Y-m-d', strtotime($request->to_date)).' 23:59:59');
        }
        
        $orders = $orders->groupBy('date')->orderBy('date', 'desc')->get();                       
        
        
        return Datatables::of($orders)
            ->addColumn('date', function ($order) {
                return date('d/m/Y', strtotime($order->date));                
            })
            ->addColumn('revenue', function ($order) {
                return number_format($order->revenue, 2, '.', '');
            })
            ->addColumn('cost_of_goods', function ($order) {
                return number_format($order->cost_of_goods, 2, '.', '');
            })
            ->addColumn('gross_profit', function ($order) {
                if($order->revenue>0)
                    return number_format($order->revenue - $order->cost_of_goods, 2, '.', ''); 
                else
                    return number_format($order->revenue + $order->cost_of_goods, 2, '.', ''); 
            })
            ->addColumn('margin', function ($order) {
                return number_format(($order->cost_of_goods / $order->revenue), 2, '.', '');
            })
            ->addColumn('order_tax', function ($order) {
                return number_format($order->order_tax, 2, '.', '');
            })
            ->rawColumns(['gross_profit', 'margin'])
            ->make(true);
            
    }

    /**
     * Display a listing of the resource.
     *
     * @return JS0N Response
     */
    public function productsReport(Request $request)
    {    
        $products = Store_products::with(['product.store_products'])->whereIn('store_id',getStoreIds());
        
        if(!empty($request->store_id)){
            $store_id = Hashids::decode($request->store_id)[0];  
            $products->where('store_id',$store_id);
        }
        
        $products = $products->orderBy('id','asc')->get();
        
        $products->map(function ($product) {                                    
            $product['current_stock'] = $product->product->store_products->where('store_id',2)->sum('quantity');
            $product['item_value'] = $product->product->price;
            $product['stock_value'] = $product->product->store_products->sum('quantity')*$product->product->price;
            
            $orders = Order::whereIn('store_id',getStoreIds())->get();      
            
            $reorder_point = 0;
            $reorder_amount = 0;
            foreach($orders as $order){
                
                $order_products = json_decode($order->order_items);
                if(count($order_products)>0){  
                    
                    $product_collection = collect($order_products);                    
                    $filtered = $product_collection->where('item_id', $product->product->id);
                    $filtered->all();
                    
                    if($filtered->count() > 0){ 
                        $reorder_point = $reorder_point + 1;  
                       
                        if(isset($filtered[0]))
                            $reorder_amount = $reorder_amount + $filtered[0]->unit_price;                       
                                               
                    }
                                                          
                }
            }
            
            $product['reorder_point'] = $reorder_point;
            $product['reorder_amount'] = $reorder_amount;
            
            return $product;
        });
        
        //dd($products->unique('product_id')->toArray());
       
        return view('company.reports.products');
    } 
    
    /**
     * Display a listing of the resource.
     *
     * @return JSON
     */
    public function getProductsReport(Request $request)
    {                    
        $products = Store_products::with(['product.store_products'])->whereIn('store_id',getStoreIds());
        
        if(!empty($request->store_id)){
            $store_id = Hashids::decode($request->store_id)[0];  
            $products->where('store_id',$store_id);
        }
        
        $products = $products->orderBy('id','asc')->get();
        
        $products->map(function ($product) use ($request) { 

            if(!empty($request->store_id)){
                $store_id = Hashids::decode($request->store_id)[0];  
                $quantity = $product->product->store_products->where('store_id',$store_id)->sum('quantity');
            }else{
                $quantity = $product->product->store_products->sum('quantity');
            }                                                    
            
            $product['code'] = $product->product->code;
            $product['sku'] = $product->product->sku;
            $product['current_stock'] = $quantity;
            $product['item_value'] = $product->product->price;
            $product['stock_value'] = $quantity * $product->product->price;
            
            $orders = Order::whereIn('store_id',getStoreIds());
            
            if(!empty($request->from_date)){
                $orders->where('created_at', '>=' , date('Y-m-d', strtotime($request->from_date)).' 00:00:00');
            }

            if(!empty($request->to_date)){
                $orders->where('created_at', '<=' , date('Y-m-d', strtotime($request->to_date)).' 23:59:59');
            }
            
            $orders = $orders->get();     
            
            $reorder_point = 0;
            $reorder_amount = 0;
            foreach($orders as $order){
                
                $order_products = json_decode($order->order_items);
                if(count($order_products)>0){  
                    
                    $product_collection = collect($order_products);                    
                    $filtered = $product_collection->where('item_id', $product->product->id);
                    $filtered->all();
                    
                    if($filtered->count() > 0){ 
                        $reorder_point = $reorder_point + 1;  
                       
                        if(isset($filtered[0]))
                            $reorder_amount = $reorder_amount + $filtered[0]->unit_price;                       
                                               
                    }
                                                          
                }
            }
            
            $product['reorder_point'] = $reorder_point;
            $product['reorder_amount'] = $reorder_amount;
            
            return $product;
        });
        
        $products = $products->unique('product_id');            
       
        return Datatables::of($products)
            ->addColumn('name', function ($product) {
                if($product->product->is_variants)
                    return '<a href="'. url('company/products/'. Hashids::encode($product->product->id).'/edit') .'" class="text-info" target="_blank">'. $product->product->name .'</a>';
                else    
                    return '<a href="'. url('company/products/edit/'. Hashids::encode($product->product->id)) .'" class="text-info" target="_blank">'. $product->product->name .'</a>';
                    
            })           
            ->rawColumns(['name'])
            ->editColumn('id', 'ID: {{$id}}')
            ->make(true);            
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return JS0N Response
     */
    public function customersReport()
    {              
        return view('company.reports.customers');
    } 
    
    /**
     * Display a listing of the resource.
     *
     * @return JSON
     */
    public function getCustomersReport(Request $request)
    {          
        $customers = Customer::with(['store','orders'])->where('company_id', Auth::id());          
        
        if(!empty($request->store_id)){
            $store_id = Hashids::decode($request->store_id)[0];  
            $customers->where('store_id',$store_id);
        }
        
        $customers = $customers->orderBy('id','asc')->get();
        
        $customers->map(function ($customer) use ($request) { 
                
                $customer_orders = $customer->orders->where('created_at', '>=' , date('Y-m-d', strtotime($request->from_date)).' 00:00:00')->where('created_at', '<=' , date('Y-m-d', strtotime($request->to_date)).' 23:59:59');                
            
                $customer['total_sales'] = $customer_orders->count('id');
                $customer['total_sale_amount'] = number_format($customer_orders->sum('order_total'), 2, '.', '');
                $customer['total_paid'] = number_format($customer_orders->sum('payment_received'), 2, '.', '');          
             
            unset($customer->orders);    
            return $customer;
        });
        
        $customers = $customers->filter(function($item) {
            return $item->total_sales != 0;
        });
       
        
        $customers = $customers->all();                         
        
        return Datatables::of($customers)
            ->addColumn('name', function ($customer) {
                return $customer->first_name .' '.$customer->last_name;               
            })
            ->addColumn('store_name', function ($customer) {
                return @$customer->store->name;                    
            })                              
            ->rawColumns(['name'])
            ->editColumn('id', 'ID: {{$id}}')
            ->make(true);            
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return JS0N Response
     */
    public function staffReport()
    {              
        return view('company.reports.staff');
    } 
    
    /**
     * Display a listing of the resource.
     *
     * @return JSON
     */
    public function getStaffReport(Request $request)
    {          
        $users = User::with(['orders'])->whereIn('store_id', getStoreIds());          
        
        if(!empty($request->store_id)){
            $store_id = Hashids::decode($request->store_id)[0];  
            $users->where('store_id',$store_id);
        }
        
        $users = $users->orderBy('id','asc')->get();
        
        $users->map(function ($user) use ($request) { 
                
                $user_orders = $user->orders->where('created_at', '>=' , date('Y-m-d', strtotime($request->from_date)).' 00:00:00')->where('created_at', '<=' , date('Y-m-d', strtotime($request->to_date)).' 23:59:59');                
            
                $user['total_sales'] = $user_orders->count('id');
                $user['total_sale_amount'] = number_format($user_orders->sum('order_total'), 2, '.', '');
                $user['total_discount'] = number_format($user_orders->sum('discount'), 2, '.', '');          
                $user['total_tax'] = number_format($user_orders->sum('order_tax'), 2, '.', '');          
             
            unset($user->orders);    
            return $user;
        });
        
//        $users = $users->filter(function($item) {
//            return $item->total_sales != 0;
//        });
       
        
        $users = $users->all();                         
        
        return Datatables::of($users)                              
            ->rawColumns([])
            ->editColumn('id', 'ID: {{$id}}')
            ->make(true);            
    }
        
    /**
     * Display a listing of the resource.
     *
     * @return JS0N Response
     */
    public function productStocks($product_id)
    {    
        $product_id = Hashids::decode($product_id)[0];  
        
        $product = Product::find($product_id);
        
        return view('company.reports.stores_stock', compact('product'));
    }  
    
    /**
     * Display a listing of the resource.
     *
     * @return JSON
     */
    public function getReportsGraphApi(Request $request)
    {
        if(\Request::wantsJson()) 
        {
            
            $orders = Order::where('store_id',Auth::user()->store_id);
            
            if(empty($request->from_date) && empty($request->to_date)){
                $orders->where('created_at', '>=' , date('Y-m-d', strtotime('-1 years')).' 00:00:00');
                $orders->where('created_at', '<=' , date('Y-m-d').' 23:59:59');
            }else{
                if(!empty($request->from_date)){
                    $orders->where('created_at', '>=' , date('Y-m-d', strtotime($request->from_date)).' 00:00:00');
                }

                if(!empty($request->to_date)){
                    $orders->where('created_at', '<=' , date('Y-m-d', strtotime($request->to_date)).' 23:59:59');
                }
            }
            
            $orders->groupBy('x')->orderBy('x', 'asc');
            
            switch ($request->type) {
                case 1: //Total Sales
                    $total_sales = $orders->get(array( DB::raw('Date(created_at) as x'), DB::raw('SUM(order_total) as y')));     
                    $total_transactions = $orders->get(array( DB::raw('Date(created_at) as x'), DB::raw('COUNT(id) as y')));                     
                    break;
                case 2: //Cash Sales    
                    $total_sales = $orders->where('payment_method',1)->get(array( DB::raw('Date(created_at) as x'), DB::raw('SUM(order_total) as y')));     
                    $total_transactions = $orders->where('payment_method',1)->get(array( DB::raw('Date(created_at) as x'), DB::raw('COUNT(id) as y')));     
                    break;
                case 3: //Card Sales   
                    $total_sales = $orders->where('payment_method',2)->get(array( DB::raw('Date(created_at) as x'), DB::raw('SUM(order_total) as y')));     
                    $total_transactions = $orders->where('payment_method',2)->get(array( DB::raw('Date(created_at) as x'), DB::raw('COUNT(id) as y')));     
                    break;
                case 4: // Avg Basket Size 
                    $total_sales = [];     
                    $total_transactions = $orders->get(array( DB::raw('Date(created_at) as x'), DB::raw('AVG(basket_size) as y')));     
                    break;
                case 5: // Avg Basket Value   
                    $total_sales = $orders->get(array( DB::raw('Date(created_at) as x'), DB::raw('AVG(order_total) as y')));     
                    $total_transactions = [];   
                    break;
                case 6: // Discount 
                    $total_sales = $orders->get(array( DB::raw('Date(created_at) as x'), DB::raw('SUM(discount) as y')));     
                    $total_transactions = $orders->get(array( DB::raw('Date(created_at) as x'), DB::raw('COUNT(id) as y')));     
                    break;                
                default:
                    $total_sales = [];
                    $total_transactions = [];
            }
            
            $report['total_sales'] = $total_sales;
            $report['total_transactions'] = $total_transactions;
            
            $status = $this->successStatus;

            return response()->json(['result' => $report], $status);
        }    
    }        
    
}
