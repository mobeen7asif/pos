<?php

namespace App\Http\Controllers\Company;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Helpers\LogActivity;
use Illuminate\Http\Request;
use Session;
use Alert;
use Image;
use File;
use Hashids;
use Datatables;
use Auth, DB, Validator;
use App\Customer;
use App\Customer_group;
use App\Store;
use App\User;
use App\Attendance_status;
use Illuminate\Support\Collection;

class CustomerController extends Controller
{
    public $successStatus = 200;
    public $errorStatus = 401;
    public $notFoundStatus = 404;
    public $badRequestStatus = 400;
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {    
        
        return view('company.customers.index');
    }

    /**
     * get users
     *
     * 
     */
    public function getCustomers(){                
        
        $customers = Customer::with(['store'])->where('company_id',Auth::id())->orderBy('id','desc')->get();
        
        return Datatables::of($customers)
            ->addColumn('profile_image', function ($customer) {
                return '<img width="30" src="'.checkImage('customers/thumbs/'. $customer->profile_image).'" />';
            })
            ->addColumn('name', function ($customer) {
                return $customer->first_name .' '.$customer->last_name;               
            })
            ->addColumn('store_name', function ($customer) {
                return @$customer->store->name;               
            })
            ->addColumn('action', function ($customer) {
                if($customer->store_id == 0){
                     return '';
                }else{
                    return '<a href="customers/'.Hashids::encode($customer->id).'/edit" class="text-primary" data-toggle="tooltip" title="Edit Customer"><i class="fa fa-edit"></i></a> 
                            <a href="javascript:void(0)" class="text-danger btn-delete" data-toggle="tooltip" title="Delete Customer" id="'.Hashids::encode($customer->id).'"><i class="fa fa-trash"></i></a>';
                }
            })
            ->editColumn('id', 'ID: {{$id}}')
            ->rawColumns(['profile_image','store_name','action'])
            ->make(true);
 
    }
    
        //search items
    public function searchCustomers(Request $request)
    {      
        if(\Request::wantsJson()) 
        {
            
            $customers = Customer::with(['orders'])->where("company_id",getComapnyIdByUser());                              
            
            if(!empty($request->q)){
                $name = $request->q;
                $customers->where(function($q) use ($name) {
                        $q->where('first_name', 'ilike', "$name%")->orWhere('last_name', 'ilike', "$name%");
                  });
                   
                  $customers->where('email', 'ilike', '%'.$name.'%');
            }           
            
            
            if(!empty($request->limit)){
                if($request->limit=='all')
                    $customers = $customers->paginate($customers->count());
                else
                    $customers = $customers->paginate($request->limit);
            }else
                $customers = $customers->paginate(10);                            
            
            $customers->setCollection(
                $customers->getCollection()
                    ->map(function($customer, $key)
                    {
                        $customer->name = $customer->first_name .' '.$customer->last_name;
                        
                        if($customer->orders->count()>0){
                            $customer->total_sales = number_format($customer->orders->sum('order_total'),2);
                            $customer->total_visits = $customer->orders->count();
                            $customer->last_visit = $customer->orders->last()->created_at->format('d/m/Y');
                        }else{
                            $customer->total_sales = 0;
                            $customer->total_visits = 0;
                            $customer->last_visit = '';
                        }
                        
                        unset($customer->orders);
                        return $customer;
                    })
                    //->sortBy('store_id')
            );
            
//            $customers->map(function ($customer) { 
//                
//                $customer['name'] = $customer['first_name'] .' '.$customer['last_name'];
//                
//                return $customer;
//            });
            
            $response['customers'] = $customers;  
            
            
            $status = $this->successStatus;
            
            return response()->json(['result' => $response], $status);
        }
    }
    
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        $groups = Customer_group::where('company_id',Auth::id())->pluck('name','id')->prepend('Select Customer Group','');
        
        return view('company.customers.create', compact('groups'));
    }
    
    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(Request $request)
    {            
        $this->validate($request, [ 
            'first_name' => 'required|max:255',
            'last_name' => 'required|max:255',
            'email' => 'required|email|max:255|unique:customers', 
            'store_id' => 'required',            
            'profile_image' => 'required|mimes:jpeg,jpg,png',
        ]);   
        
        $requestData = $request->all();         
        $requestData['company_id'] = Auth::id();
        
        $customer = Customer::create($requestData);        
        
        //save profile image
        if($request->hasFile('profile_image')){
            $destinationPath = 'uploads/customers'; // upload path
            $image = $request->file('profile_image'); // file
            $extension = $image->getClientOriginalExtension(); // getting image extension
            $fileName = $customer->id.'-'.str_random(10).'.'.$extension; // renameing image
            
            $img = Image::make($image->getRealPath());
            $img->resize(100, 100, function ($constraint) {
                $constraint->aspectRatio();
            })->save($destinationPath.'/thumbs/'.$fileName);

            $image->move($destinationPath, $fileName); // uploading file to given path
            
            //update image record
            $customer_image['profile_image'] = $fileName;
            $customer->update($customer_image);
        }
        
        // sync customers
        updateSyncData('customer',$customer->id);  
        
        Session::flash('success', 'Customer added!');        

        return redirect('company/customers');  
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return JSON
     */
    public function storeApi(Request $request)
    {            
        if(isset($request->customers)){
          $customers = json_decode($request->customers);
    
          foreach($customers as $customer_request)
            {
//               $customer_exist = Customer::where('email',$customer_request->email)->first();
//               if(!$customer_exist){
                   
                $customer_data['id'] = $customer_request->customer_id;
                $customer = Customer::firstOrNew($customer_data);

                $customer->id = $customer_request->customer_id;
                $customer->first_name = $customer_request->first_name;
                $customer->last_name = $customer_request->last_name;
                $customer->email = $customer_request->email;
                $customer->country_id = $customer_request->country_id;
                $customer->mobile = $customer_request->mobile;
                $customer->ref_code = $customer_request->ref_code;
                $customer->company_name = $customer_request->company_name;
                $customer->address = $customer_request->address;
                $customer->state = $customer_request->state;
                $customer->city = $customer_request->city;
                $customer->zip_code = $customer_request->zip_code;
                $customer->note = $customer_request->note;
                $customer->current_billing_address = $customer_request->current_billing_address;
                $customer->current_shipping_delivery_address = $customer_request->current_shipping_delivery_address;
                $customer->customer_group_id = isset($customer_request->customer_group_id) ? $customer_request->customer_group_id : 0;
                $customer->company_id = getComapnyIdByUser();
                $customer->store_id = Auth::user()->store_id;
                $customer->profile_image = 'default.png';
                $customer->created_at = $customer_request->created_at;
                $customer->updated_at = $customer_request->created_at;

                $customer->save();               

                // sync customers
                updateSyncData('customer',$customer->id);
              // }
                      
            }
        
            $response['success'] =  'Customer added!';

            return response()->json(['result'=>$response], $this->successStatus);
        }else{
            $response['error'] =  'customers key is required';

            return response()->json(['result'=>$response], $this->badRequestStatus); 
        }
        
        
    }
    
    /**
     * Show the detail of user.
     *
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        $id = Hashids::decode($id)[0];
        
        $groups = Customer_group::where('company_id',Auth::id())->pluck('name','id')->prepend('Select Customer Group','');
        
        $customer = Customer::with(['store'])->findOrFail($id);
        
        return view('company.users.user_profile', compact('user'));
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {
        $id = Hashids::decode($id)[0];
        
        $groups = Customer_group::where('company_id',Auth::id())->pluck('name','id')->prepend('Select Customer Group','');
        
        $customer = Customer::with(['store'])->findOrFail($id);

        return view('company.customers.edit', compact('customer', 'groups'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update($id, Request $request)
    {
        $id = Hashids::decode($id)[0];
       
        $this->validate($request, [ 
            'first_name' => 'required|max:255',
            'last_name' => 'required|max:255',      
            'email' => "required|email|max:255|unique:users,email,$id",
            'store_id' => 'required',            
        ]);                  
        
        $customer = Customer::findOrFail($id);
        
        $requestData = $request->all(); 
        
        $customer->update($requestData);
        
        //save profile image
        if($request->hasFile('profile_image')){
            $destinationPath = 'uploads/customers'; // upload path
            $image = $request->file('profile_image'); // file
            $extension = $image->getClientOriginalExtension(); // getting image extension
            $fileName = $customer->id.'-'.str_random(10).'.'.$extension; // renameing image
            
            $img = Image::make($image->getRealPath());
            $img->resize(100, 100, function ($constraint) {
                $constraint->aspectRatio();
            })->save($destinationPath.'/thumbs/'.$fileName);

            $image->move($destinationPath, $fileName); // uploading file to given path
            
            //remove old image
            File::delete($destinationPath . $customer->profile_image);
            File::delete($destinationPath .'/thumbs/'. $customer->profile_image);
            
            //update image record
            $customer_image['profile_image'] = $fileName;
            $customer->update($customer_image);
        }
        
        // sync customers
        updateSyncData('customer',$customer->id);  
        
        Session::flash('success', 'Customer updated!');

        return redirect('company/customers');
    }
    
    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @param \Illuminate\Http\Request $request
     *
     * @return JOSN
     */
    public function updateApi($id, Request $request)
    {
        $validator = Validator::make($request->all(), [
            'first_name' => 'required|max:255',
            'last_name' => 'required|max:255',
            'email' => "required|email|max:255|unique:users,email,$id", 
            'country_id' => 'required',              
        ]);   
        
        if ($validator->fails()) {
            $response['error'] = $validator->errors();
            return response()->json(['result'=>$response], $this->badRequestStatus);                 
        }
        
        $customer = Customer::findOrFail($id);
        
        $requestData = $request->all(); 
        
        $customer->update($requestData);               
        
        // sync customers
        updateSyncData('customer',$customer->id);  
        
        $response['customer'] =  $customer;
        $response['success'] =  'Customer updated!';

        return response()->json(['result'=>$response], $this->successStatus);                                    
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function destroy($id)
    {
        $id = Hashids::decode($id)[0];

        $customer = Customer::find($id);
        
        if($customer){
            // sync customers
            updateSyncData('delete_customer',$customer->id,[$customer->store_id]);  
        
            $customer->delete();
            $response['success'] = 'Customer deleted!';
            $status = $this->successStatus;  
        }else{
            $response['error'] = 'Customer not exist against this id!';
            $status = $this->notFoundStatus;  
        }
        
        return response()->json(['result'=>$response], $status);
    }           
    
}
