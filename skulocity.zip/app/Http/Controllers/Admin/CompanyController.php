<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

use App\Company;
use App\Country;
use App\Store;
use App\Customer;
use App\Email_template;
use Illuminate\Http\Request;
use Session;
use Alert;
use Image;
use File;
use Hashids;
use Datatables;

class CompanyController extends Controller
{
    public $successStatus = 200;
    public $errorStatus = 401;
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {                
        return view('admin.companies.index');
    }
    
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function getCompanies()
    {        
        $companies = Company::with(['store'])->get();                
        
        return Datatables::of($companies)
            ->addColumn('logo', function ($company) {
                $logo = $company->logo;
                if(empty($company->logo))
                    $logo = 'no_image.png';
                
                return '<img width="30" src="'.checkImage('companies/thumbs/'. $logo).'" />';
            })
            ->addColumn('total_stores', function ($company) {
                return @$company->store->count();
            })
            ->addColumn('action', function ($company) {
                return '<a href="companies/'. Hashids::encode($company->id).'/edit" class="text-primary" data-toggle="tooltip" title="Edit Company"><i class="fa fa-edit"></i></a> 
                        <a href="companies/company-login/'. Hashids::encode($company->id).'" class="text-success" target="_blank" data-toggle="tooltip" title="Company Login"><i class="fa fa-sign-in"></i></a>';
            })           
            ->editColumn('id', 'ID: {{$id}}')
            ->rawColumns(['logo', 'total_stores', 'action'])
            ->make(true);
            
    }    
    
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {               
        return view('admin.companies.create');                
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(Request $request)
    {            
        $this->validate($request, [ 
            'name' => 'required|max:255',
            'email' => 'required|email|max:255|unique:companies',
            'password' => 'required|min:6|confirmed',
            'country' => 'required',
//            'state' => 'required',
//            'city' => 'required',
//            'zip' => 'required',
//            'address' => 'required',       
//            'logo' => 'required|mimes:jpeg,jpg,png',
        ]);   
        
       $requestData = $request->all();  
       $password = $requestData['password'];
       $requestData['password'] = bcrypt($requestData['password']);
        
        $company = Company::create($requestData);
        
        if($company){
            
            $email_data = Email_template::where('key','company_register')->first();

            $site_link = '<a href="'.url('company/login').'">Clck here for login</a>';

            $email_to            = $company->email;
            $email_from            = $email_data->from;
            $email_subject            = $email_data->subject;
            $email_body          = $email_data->content;
            
            $email_body = str_replace('{client_name}',$company->name,$email_body);
            $email_body = str_replace('{site_link}',$site_link,$email_body);
            $email_body = str_replace('{email}',$company->email,$email_body);
            $email_body = str_replace('{password}',$password,$email_body);            
            $email_body = str_replace('{site_name}',settingValue('site_title'),$email_body);
            $body = $email_body;
            Email_template::sendEmail($email_to,$email_data,$body);
            
            $store['company_id'] = $company->id;
            $store['name'] = 'Default';
            $store['address'] = $company->address .' '.$company->city;
            $store['image'] = 'default.jpg';
            Store::create($store);
            
            
            $customer['first_name'] = 'Walk-in';
            $customer['last_name'] = 'Customer';
            $customer['email'] = $request->email;
            $customer['company_id'] = $company->id;
            $customer['country_id'] = $request->country;
            $customer['address'] = $request->address;
            $customer['city'] = $request->city;
            $customer['state'] = $request->state;
            $customer['zip_code'] = $request->zip;
            $customer['store_id'] = 0;
            $customer_data = Customer::create($customer);
            
            // sync customers
            //updateSyncData('customer',$customer_data->id);  
        }
        
        //save logo image
        if($request->hasFile('logo')){
            $destinationPath = 'uploads/companies'; // upload path
            $image = $request->file('logo'); // file
            $extension = $image->getClientOriginalExtension(); // getting image extension
            $fileName = $company->id.'-'.str_random(10).'.'.$extension; // renameing image
            
            $img = Image::make($image->getRealPath());
            $img->resize(100, 100, function ($constraint) {
                $constraint->aspectRatio();
            })->save($destinationPath.'/thumbs/'.$fileName);

            $image->move($destinationPath, $fileName); // uploading file to given path
            
            //update image record
            $company_image['logo'] = $fileName;
            $company->update($company_image);
        }
        
        Session::flash('success', 'Company added!');         

        return redirect('admin/companies');  
    }
    
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {
                        
        $id = Hashids::decode($id)[0];
        
        $company = Company::findOrFail($id);       
        
        return view('admin.companies.edit', compact('company'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update($id, Request $request)
    {        
        $id = Hashids::decode($id)[0];
        
        $this->validate($request, [ 
            'name' => 'required|max:255',
            'country' => 'required',
//            'state' => 'required',
//            'city' => 'required',
//            'zip' => 'required',
//            'address' => 'required',                                         
        ]);
        
        $requestData = $request->all();                   
        
        $company = Company::findOrFail($id);
        $company->update($requestData);        
        
        //save category image
        if($request->hasFile('logo')){
            $destinationPath = 'uploads/companies'; // upload path
            $image = $request->file('logo'); // file
            $extension = $image->getClientOriginalExtension(); // getting image extension
            $fileName = $company->id.'-'.str_random(10).'.'.$extension; // renameing image
            
            $img = Image::make($image->getRealPath());
            $img->resize(100, 100, function ($constraint) {
                $constraint->aspectRatio();
            })->save($destinationPath.'/thumbs/'.$fileName);

            $image->move($destinationPath, $fileName); // uploading file to given path
            
            //remove old image
            File::delete($destinationPath . $company->logo);
            
            //update image record
            $company_image['logo'] = $fileName;
            $company->update($company_image);
        }                        
        
        Session::flash('success', 'Company updated!');  

        return redirect('admin/companies');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function destroy($id)
    {   
        $id = Hashids::decode($id)[0];
        
        $company = Company::find($id);
        
        if($company){
            $company->delete();
            $response['success'] = 'Company deleted!';
            $status = $this->successStatus;  
        }else{
            $response['error'] = 'Company not exist against this id!';
            $status = $this->errorStatus;  
        }
        
        return response()->json(['result'=>$response], $status);

    }
    
    
    /**
     * Company Login.
     *
     * @param \Illuminate\Http\Request $company_id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function companyLogin($company_id)
    {            
        $id = Hashids::decode($company_id)[0];
        
        Auth::guard('company')->loginUsingId($id);
        
        return redirect('company/dashboard');
    }
    
}
