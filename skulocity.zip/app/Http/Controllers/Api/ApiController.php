<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use App\Helpers\LogActivity;
use App\User;
use App\Country;
use Response;
use Carbon\Carbon;
use DB;
use Image;
use File;
use App\Attendance_status;

class ApiController extends Controller
{
    public $successStatus = 200;
    public $badRequestStatus = 400;
    public $errorStatus = 401;
    public $notFoundStatus = 404;
    
    /**
     * Register api
     *
     * @return \Illuminate\Http\Response
     */
    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [            
            'name' => 'required|string',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:6',
        ]);
        
        $input = $request->all();        

        if ($validator->fails()) {
            $response['error'] = $validator->errors();
            return response()->json(['result'=>$response], $this->badRequestStatus);                 
        }

        $userdata['email'] = $input['email'];
        
        $user = User::firstOrNew($userdata);
        
        $user->name = $input['name'];
        $user->password = bcrypt($input['password']);
        $user->save();
        
        $response['user'] =  $user;
        $response['token'] =  $user->createToken('Skulocity')->accessToken;
        $response['success'] =  'You have successfully register.';

        return response()->json(['result'=>$response], $this->successStatus);
    }
    
    /**
     * login api
     *
     * @return \Illuminate\Http\Response
     */
    public function login(Request $request)
    {  
        $validator = Validator::make($request->all(), [            
            'email' => 'required|email',
            'password' => 'required',
        ]);

        if ($validator->fails()) {
            $response['error'] = $validator->errors();
            return response()->json(['result'=>$response], $this->badRequestStatus);            
        }
        
        $input = $request->all();

        if(Auth::attempt(['email' => $input['email'], 'password' => $input['password']])){                   
            $user = Auth::user();            
            $user->last_online_time = date("Y-m-d H:i:s");
            $user->update();
            
            if($user->status==0){
               $response['error'] = "You account is blocked please contact with store management.";
               return response()->json(['result'=>$response], $this->badRequestStatus);     
            }
            
            LogActivity::addToUserLog($user->id,'success_login','Success Login');                        
                                     
            $response['user'] =  $this->getUserMap($user);

            $response['token'] =  $user->createToken('Skulocity')->accessToken;
            $response['success'] =  'You have successfully login.';
            
            $status = $this->successStatus;
            
            return response()->json(['result'=>$response], $status);    
        }
        else{
            
            LogActivity::addToUserLog($input['email'],'login_failed','Login Failed');
            
            $response['error'] = "You have entered an invalid email or password";
            $status = $this->errorStatus;
            
            return response()->json(['result'=>$response], $status);    
        }
        
    }   
    
    /**
     * getProductsMap function
     *
     * @param  int  $user
     * 
     * @return \Illuminate\Http\Response
     */    
    
    private function getUserMap($user){
        
        $user_data = User::with(
                [
                    'store.company.company_setting',
                    'store.company.customers' => function ($query) {
                        $query->where('store_id', 0);
                    },
                    'store.company.store',
                    'store.company.currencies',
                    'store.company.tax_rates',
                    'store.company.shipping_options',
                    'store.company.customer_groups'
                ])->find($user->id);
        
        $user_data['profile_thumbnail'] = checkImage('users/thumbs/'. $user->profile_image);
        $user_data['profile_image'] = checkImage('users/'. $user->profile_image);            
        
        $user_data->store->company->stores = $user_data->store->company->store;
        
        $user_data->store->company->currencies->map( function ($currency) {
                
            $currency->default = ($currency->id == companySettingValueApi('currency_id') ? true : false);

            return $currency;
        });          
        
        $user_data->store->company->tax_rates->map( function ($tax_rate) {
                
            $tax_rate->default = ($tax_rate->id == companySettingValueApi('tax_id') ? true : false);

            return $tax_rate;
        });          
        
        $user_data->store->company->shipping_options->map( function ($shipping_option) {
                
            $shipping_option->default = ($shipping_option->id == companySettingValueApi('shipping_id') ? true : false);

            return $shipping_option;
        });
           
        unset($user_data->store->company->store);
         // return $products->all();
        
        return $user_data;
    }
   
    /**
     * profileDetails api
     *
     * @return \Illuminate\Http\Response
     */ 
    public function profileDetails()
    { 
      $user = Auth::user();
            
      if ($user) {                                            
           $user['profile_thumbnail'] = checkImage('users/thumbs/'. $user->profile_image);
           $user['profile_image'] = checkImage('users/'. $user->profile_image);
           $response['user'] = $user;
           $status = $this->successStatus;
        }else{
            $response['error'] = "Profile details not exist against this user";
            $status = $this->errorStatus;
        }
       
       return response()->json(['result' => $response], $status);
   }
   
   /**
     * updateProfile api
     *
     * @return \Illuminate\Http\Response
     */ 
    public function updateProfile(Request $request)
    {     
        $user = Auth::user();

        $validator = Validator::make($request->all(), [
            'name'          => 'required',
            'email'         => "email|unique:users,email,$user->id" ,
            'dob'    => 'required',
            'pin'     => 'digits:6',
            'blood_group'     => 'required',
            'profile_status'     => 'required',
        ]);
        //validate if user does not have image
        
        if ($validator->fails()) {
            $response['error'] = $validator->errors();
            return response()->json(['result'=>$response], $this->errorStatus);                 
        }

        $input = $request->all();
        
        $record = User::findOrFail($user->id);
        
        $record->update($input);

        /*-----image manipulation-----*/
        if ($request->hasFile('profile_image'))
        {
            //validate if user has image
            $validator = Validator::make($request->all(), [
                'profile_image' => 'image|mimes:jpeg,png,jpg,gif'
            ]);
            if ($validator->fails()) {
                $response['error'] = $validator->errors();
                return response()->json(['result'=>$response], $this->errorStatus);                 
            }

            /*image make process*/
            $image = $request->file('profile_image');
            $image_name   = $record->id.'_'.str_random(10).'.'.$image->getClientOriginalExtension();
            
            $destinationPath = public_path('/uploads/users/thumbs');
            $img = Image::make($image->getRealPath());
            
            /*move image to thumbs folder*/
            $img->resize(100, 100, function ($constraint) {
                $constraint->aspectRatio();
            })->save($destinationPath.'/'.$image_name);

            /*move image to folder*/
            $destinationPath = public_path('/uploads/users/');
            $image->move($destinationPath, $image_name);
            
            /*unlink old image*/
            @unlink(public_path("/uploads/users/$user->profile_image"));
            @unlink(public_path("/uploads/users/thumbs/$user->profile_image"));

            // save image to db
            $record->profile_image = $image_name;
            $record->save(); 
        }
        
        $response['success']    =  'Profile updated successfully';
        return response()->json(['result'=>$response], $this->successStatus);
    }
    
   /**
     * changePassword api
     *
     * @return \Illuminate\Http\Response
     */ 
   
   public function changePassword(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'current_password' => 'required', 
            'password' => 'required|confirmed|min:6'            
        ]);

        if ($validator->fails()){
            $response['error'] = $validator->errors();
            return response()->json(['result'=>$response], $this->errorStatus); 
        }

        $user = Auth::guard('api')->user();

         //checking the old password first
         $check  = Auth::guard('web')->attempt([
             'email' => $user->email,
             'password' => $request->current_password
         ]);

         if($check) {
             $user->password = bcrypt($request->password);
             $user->token()->revoke();
             $token = $user->createToken('Bat App')->accessToken;

             //Changing the type
             $user->save();

             $response['user'] = $user;
             $response['token'] = $token;

             return response()->json(['result'=>$response], $this->successStatus);
         
        }else{

            $response['error']['current_password'] = 'Your current password is incorrect, please try again.';
            return response()->json(['result'=>$response], $this->errorStatus); 
            
        }
    }
    
    /**
     * logout api
     *
     * @return \Illuminate\Http\Response
     */ 
    public function logout()
    { 
       
      if (Auth::check()) {
          
         Auth::user()->AauthAcessToken()->delete();
           $response['success'] = "You have successfully logout";
           $status = $this->successStatus;            
        }else{             
            $response['error'] = "Oops! some error occur not successfully logout. Please try again";
        }
       
       return response()->json(['result' => $response], $status);
   } 
   
   /**
     * Forget password
     *
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function forgetPassword(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|exists:users'
        ],[
            'email.exists' => "We can't find a user with that e-mail address."
        ]);        
        
        if ($validator->fails()) {
            $response['error'] = $validator->errors();
            return response()->json(['result'=>$response], $this->badRequestStatus);                 
        }
        
        $headers =  'MIME-Version: 1.0' . "\r\n"; 
        $headers .= 'From: Your name <info@address.com>' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; 

        mail($request->email,"Forget Password",'Forget Password',$headers);
        
        $response['success'] = 'Email successfully sent.';
        return response()->json(['result'=>$response], $this->successStatus);
    }
    
    
    
    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function loginWithPin(Request $request)
    {            
       $validator = Validator::make($request->all(), [            
            'pin_code' => 'required',
        ]);

        if ($validator->fails()) {
            $response['error'] = $validator->errors();
            return response()->json(['result'=>$response], $this->badRequestStatus);            
        }
        
        $input = $request->all();
        $user_id = Auth::id();
        $user = User::where('id',$user_id)->where('pin_code',$input['pin_code'])->first();
        
        if($user){
                     
            $user->last_online_time = date("Y-m-d H:i:s");
            $user->update();
            
            
            if(!empty($input['timestamp'])){
                $attData['attendance_time'] = $input['attendance_time'];       
            }else{
                $attData['attendance_time'] = date("Y-m-d H:i:s");
            }
            
            $attData['user_id'] = $user_id;        
            $attData['date'] = date('Y-m-d'); 
            $attData['status'] = 1; 
                
            if(isset($input['type']) && ($input['type'] == 1)){
                
                Attendance_status::create($attData);
                
//                $attendance = Attendance_status::firstOrNew($attData);
//
//                $attendance->save();
                
                LogActivity::addToUserLog($user_id,'checkin_success','Success Check In');
                
                $status = $this->successStatus;
                $response['success'] =  'You have successfully check in.'; 
            
            }elseif(isset($input['type']) && ($input['type'] == 2)){
                
                $attData['status'] = 2; 
                Attendance_status::create($attData);
                
//                $check_in_status = Attendance_status::where($attData)->first();
//
//                if($check_in_status){
//                    $attData['status'] = 2; 
//
//                    $attendance = Attendance_status::firstOrNew($attData);
//                    $attendance->save();
//                    
                    
                    //$this->logout();
                    
                    LogActivity::addToUserLog($user_id,'checkout_success','Success Check Out');
                    
                    $status = $this->successStatus;
                    $response['success'] =  'You have successfully check out.';  
//                }else{
//                    
//                    LogActivity::addToUserLog($user_id,'checkout_failed','Check Out Failed');
//                    
//                    $status = $this->errorStatus;
//                    $response['success'] =  'Please check in first.';
//                }
            }else{
                
                LogActivity::addToUserLog($user_id,'login_success_with_pin','Success Login with Pin Code');
                
                $status = $this->successStatus;
                $response['success'] =  'You have successfully login.';
            }
            
            return response()->json(['result'=>$response], $status);    
        }
        else{
            
            LogActivity::addToUserLog($user_id,'login_failed_with_pin','Login Failed! Invalid pin code');
            
            $response['error'] = "You have entered an invalid pin code";
            
            return response()->json(['result'=>$response], $this->errorStatus);    
        }
    }
    
    /**
     * Check internet status
     *
     * @return JSON
     */
    public function pingServer()
    {
        $user = Auth::user();            
        $user->last_online_time = date("Y-m-d H:i:s");
        $user->update();
        
        $response['timestamp'] = date("d-m-Y h:i a");
        
        return response()->json(['result'=>$response], $this->successStatus); 
    }
    
    
    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function loginMultiWithPin(Request $request)
    {   
        if(isset($request->attedence_data)){
          $attedence_data = json_decode($request->attedence_data,true);
                    
          foreach($attedence_data as $attedence)
          {               
            $user_id = $attedence['user_id'];
            $user = User::find($user_id); 

            if($user){

                $user->last_online_time = $attedence['attendance_time'];
                $user->update();

                $attData['created_at'] = $attedence['attendance_time'];                  
                $attData['updated_at'] = $attedence['attendance_time'];                  
                $attData['user_id'] = $user_id;        
                $attData['date'] = date('Y-m-d',strtotime($attedence['attendance_time'])); 
                $attData['status'] = 1; 

                if(isset($attedence['type']) && ($attedence['type'] == 1)){
                   
                    Attendance_status::create($attData);                
                    LogActivity::addToUserLog($user_id,'checkin_success','Success Check In');

                }elseif(isset($attedence['type']) && ($attedence['type'] == 2)){

                    $attData['status'] = 2; 
                    Attendance_status::create($attData);                                

                    LogActivity::addToUserLog($user_id,'checkout_success','Success Check Out');  
                }else{
                    LogActivity::addToUserLog($user_id,'login_success_with_pin','Success Login with Pin Code');
                }
   
            }  
          }
        }
      
        
      $response['timestamp'] = date("d-m-Y h:i a");
        
      return response()->json(['result'=>$response], $this->successStatus);   
    }
    
}




