<?php
return [
    'location'  => [
       'left'   => 'Left',
       'right'  => 'Right',
       'top'    => 'Top',
       'bottom' => 'Bottom',
    ]
];